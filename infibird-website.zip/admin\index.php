<?php
/**
 * Infibird Concepts – simple admin panel
 * Lets the site owner replace website photos and manage products
 * without touching code. No database needed.
 *
 * Data:    ../data/content.json
 * Uploads: ../uploads/
 * Password hash is stored in ./auth.php (created on first visit).
 */

declare(strict_types=1);

const SITE_ROOT    = __DIR__ . '/..';
const CONTENT_FILE = SITE_ROOT . '/data/content.json';
const UPLOAD_DIR   = SITE_ROOT . '/uploads';
const AUTH_FILE    = __DIR__ . '/auth.php';
const ATTEMPTS_FILE = __DIR__ . '/.attempts.json';
const MAX_UPLOAD_MB = 8;
const MAX_ATTEMPTS  = 5;      // failed logins…
const LOCK_MINUTES  = 15;     // …before locking for this long

ini_set('session.use_strict_mode', '1');
session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'Strict',
    'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
]);
session_name('infibird_admin');
session_start();

header('X-Robots-Tag: noindex, nofollow');
header('X-Frame-Options: DENY');

/* ---------------- helpers ---------------- */

function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function flash(string $msg, string $type = 'ok'): void { $_SESSION['flash'] = [$msg, $type]; }

function redirect(string $tab = ''): void {
    header('Location: index.php' . ($tab ? '?tab=' . urlencode($tab) : ''));
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) {
        http_response_code(400);
        exit('Session expired. Please go back and refresh the page.');
    }
}

function load_content(): array {
    $data = is_file(CONTENT_FILE) ? json_decode((string)file_get_contents(CONTENT_FILE), true) : null;
    if (!is_array($data)) $data = [];
    $data['slots']    = $data['slots']    ?? [];
    $data['products'] = $data['products'] ?? [];
    return $data;
}

function save_content(array $data): bool {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) return false;
    $tmp = CONTENT_FILE . '.tmp';
    if (file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    return rename($tmp, CONTENT_FILE);
}

function client_ip(): string { return $_SERVER['REMOTE_ADDR'] ?? 'unknown'; }

function attempts_load(): array {
    $a = is_file(ATTEMPTS_FILE) ? json_decode((string)file_get_contents(ATTEMPTS_FILE), true) : [];
    return is_array($a) ? $a : [];
}
function attempts_save(array $a): void { @file_put_contents(ATTEMPTS_FILE, json_encode($a), LOCK_EX); }

function is_locked(): int {
    $a = attempts_load()[client_ip()] ?? null;
    if (!$a || $a['count'] < MAX_ATTEMPTS) return 0;
    $left = ($a['time'] + LOCK_MINUTES * 60) - time();
    return $left > 0 ? (int)ceil($left / 60) : 0;
}

function record_failure(): void {
    $all = attempts_load();
    $ip = client_ip();
    $cur = $all[$ip] ?? ['count' => 0, 'time' => time()];
    if (time() - $cur['time'] > LOCK_MINUTES * 60) $cur = ['count' => 0, 'time' => time()];
    $cur['count']++;
    $cur['time'] = time();
    $all[$ip] = $cur;
    attempts_save($all);
}

function clear_failures(): void {
    $all = attempts_load();
    unset($all[client_ip()]);
    attempts_save($all);
}

function get_hash(): ?string {
    if (!is_file(AUTH_FILE)) return null;
    $hash = include AUTH_FILE;
    return is_string($hash) && $hash !== '' ? $hash : null;
}

function set_password(string $pw): bool {
    $hash = password_hash($pw, PASSWORD_DEFAULT);
    $php  = "<?php\n// Admin password hash – do not share. Delete this file to reset the password.\nreturn " . var_export($hash, true) . ";\n";
    return file_put_contents(AUTH_FILE, $php, LOCK_EX) !== false;
}

/**
 * Validate an uploaded image, resize it (if GD is available) and save it to /uploads.
 * Returns the web path (e.g. "uploads/abc123.jpg") or throws on error.
 */
function handle_upload(string $field, int $maxSide = 1600): string {
    $f = $_FILES[$field] ?? null;
    if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('Please choose a photo.');
    }
    if ($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE || $f['size'] > MAX_UPLOAD_MB * 1024 * 1024) {
        throw new RuntimeException('Photo is too large. Maximum is ' . MAX_UPLOAD_MB . ' MB.');
    }
    if ($f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) {
        throw new RuntimeException('Upload failed. Please try again.');
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $types = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($types[$mime])) throw new RuntimeException('Only JPG, PNG or WEBP photos are allowed.');
    $info = @getimagesize($f['tmp_name']);
    if (!$info || $info[0] < 1 || $info[1] < 1) throw new RuntimeException('That file is not a valid image.');

    if (!is_dir(UPLOAD_DIR) && !mkdir(UPLOAD_DIR, 0755, true)) throw new RuntimeException('Cannot create uploads folder.');
    $name = date('Ymd') . '-' . bin2hex(random_bytes(6));

    // Preferred: re-encode with GD (resizes big phone photos and strips anything that isn't image data)
    if (extension_loaded('gd')) {
        $src = match ($mime) {
            'image/jpeg' => @imagecreatefromjpeg($f['tmp_name']),
            'image/png'  => @imagecreatefrompng($f['tmp_name']),
            'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($f['tmp_name']) : false,
        };
        if ($src) {
            // Fix sideways phone photos
            if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
                $exif = @exif_read_data($f['tmp_name']);
                $o = $exif['Orientation'] ?? 1;
                if ($o == 3) $src = imagerotate($src, 180, 0);
                elseif ($o == 6) $src = imagerotate($src, -90, 0);
                elseif ($o == 8) $src = imagerotate($src, 90, 0);
            }
            $w = imagesx($src); $hgt = imagesy($src);
            $scale = min(1, $maxSide / max($w, $hgt));
            $nw = max(1, (int)round($w * $scale)); $nh = max(1, (int)round($hgt * $scale));
            $dst = imagecreatetruecolor($nw, $nh);
            imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255)); // white behind transparent PNGs
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $hgt);
            $file = $name . '.jpg';
            $ok = imagejpeg($dst, UPLOAD_DIR . '/' . $file, 85);
            imagedestroy($src); imagedestroy($dst);
            if (!$ok) throw new RuntimeException('Could not save the photo.');
            return 'uploads/' . $file;
        }
    }

    // Fallback without GD: store the validated file as-is
    $file = $name . '.' . $types[$mime];
    if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . '/' . $file)) throw new RuntimeException('Could not save the photo.');
    return 'uploads/' . $file;
}

/** Delete a previously uploaded file (never touches the original /images files). */
function delete_upload(?string $path, array $data): void {
    if (!$path || !str_starts_with($path, 'uploads/')) return;
    // keep it if still used somewhere else
    foreach ($data['slots'] as $s) if (($s['image'] ?? '') === $path) return;
    foreach ($data['products'] as $p) if (($p['image'] ?? '') === $path) return;
    $full = UPLOAD_DIR . '/' . basename($path);
    if (is_file($full)) @unlink($full);
}

function clean_text(string $key, int $max): string {
    $v = trim((string)($_POST[$key] ?? ''));
    return mb_substr(preg_replace('/\s+/u', ' ', $v), 0, $max);
}

/* ---------------- auth flow ---------------- */

$hash   = get_hash();
$action = $_POST['action'] ?? '';
$error  = '';

// First run: create password
if ($hash === null) {
    if ($action === 'setup') {
        check_csrf();
        $pw = (string)($_POST['password'] ?? '');
        if (strlen($pw) < 8) $error = 'Password must be at least 8 characters.';
        elseif ($pw !== ($_POST['password2'] ?? '')) $error = 'Passwords do not match.';
        elseif (!set_password($pw)) $error = 'Could not save password. Check folder permissions.';
        else {
            session_regenerate_id(true);
            $_SESSION['admin'] = true;
            flash('Password created. Welcome to your admin panel!');
            redirect();
        }
    }
    render_auth('setup', $error);
    exit;
}

if ($action === 'logout') {
    check_csrf();
    $_SESSION = [];
    session_destroy();
    header('Location: index.php');
    exit;
}

if (empty($_SESSION['admin'])) {
    if ($action === 'login') {
        check_csrf();
        if ($mins = is_locked()) {
            $error = "Too many failed attempts. Try again in $mins minute(s).";
        } elseif (password_verify((string)($_POST['password'] ?? ''), $hash)) {
            clear_failures();
            session_regenerate_id(true);
            $_SESSION['admin'] = true;
            redirect();
        } else {
            record_failure();
            usleep(700000);
            $error = 'Wrong password.';
        }
    }
    render_auth('login', $error);
    exit;
}

/* ---------------- admin actions ---------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // A too-large upload empties $_POST entirely
    if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        flash('Photo is too large for the server. Try a smaller photo (under ' . MAX_UPLOAD_MB . ' MB).', 'err');
        redirect($_GET['tab'] ?? '');
    }
    check_csrf();
    $data = load_content();
    $tab  = 'photos';

    try {
        switch ($action) {
            case 'slot_upload':
                $key = (string)($_POST['slot'] ?? '');
                if (!isset($data['slots'][$key])) throw new RuntimeException('Unknown photo.');
                $old = $data['slots'][$key]['image'] ?? null;
                $data['slots'][$key]['image'] = handle_upload('photo', 1800);
                if (!save_content($data)) throw new RuntimeException('Could not save changes.');
                delete_upload($old, $data);
                flash('Photo updated: ' . $data['slots'][$key]['label']);
                break;

            case 'product_save':
                $tab = 'products';
                $id = (string)($_POST['id'] ?? '');
                $name = clean_text('name', 120);
                if ($name === '') throw new RuntimeException('Product name is required.');
                $cat = ($_POST['category'] ?? '') === 'consumable' ? 'consumable' : 'instrument';
                $tag = clean_text('tag', 30) ?: ($cat === 'consumable' ? 'Consumable' : 'Instrument');
                $desc = clean_text('desc', 400);
                $hasFile = ($_FILES['photo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;

                if ($id === '') { // new
                    if (!$hasFile) throw new RuntimeException('Please choose a photo for the new product.');
                    $img = handle_upload('photo', 1200);
                    $data['products'][] = ['id' => 'p' . bin2hex(random_bytes(4)), 'name' => $name, 'category' => $cat, 'tag' => $tag, 'desc' => $desc, 'image' => $img];
                    if (!save_content($data)) throw new RuntimeException('Could not save changes.');
                    flash("Product added: $name");
                } else {
                    $found = false;
                    foreach ($data['products'] as &$p) {
                        if ($p['id'] !== $id) continue;
                        $found = true;
                        $old = $p['image'];
                        if ($hasFile) $p['image'] = handle_upload('photo', 1200);
                        $p['name'] = $name; $p['category'] = $cat; $p['tag'] = $tag; $p['desc'] = $desc;
                        break;
                    }
                    unset($p);
                    if (!$found) throw new RuntimeException('Product not found.');
                    if (!save_content($data)) throw new RuntimeException('Could not save changes.');
                    if ($hasFile) delete_upload($old, $data);
                    flash("Product updated: $name");
                }
                break;

            case 'product_delete':
                $tab = 'products';
                $id = (string)($_POST['id'] ?? '');
                foreach ($data['products'] as $i => $p) {
                    if ($p['id'] === $id) {
                        array_splice($data['products'], $i, 1);
                        if (!save_content($data)) throw new RuntimeException('Could not save changes.');
                        delete_upload($p['image'], $data);
                        flash('Product deleted: ' . $p['name']);
                        break 2;
                    }
                }
                throw new RuntimeException('Product not found.');

            case 'product_move':
                $tab = 'products';
                $id = (string)($_POST['id'] ?? '');
                $dir = ($_POST['dir'] ?? '') === 'up' ? -1 : 1;
                foreach ($data['products'] as $i => $p) {
                    if ($p['id'] === $id) {
                        $j = $i + $dir;
                        if ($j >= 0 && $j < count($data['products'])) {
                            [$data['products'][$i], $data['products'][$j]] = [$data['products'][$j], $data['products'][$i]];
                            save_content($data);
                        }
                        break;
                    }
                }
                break;

            case 'password':
                $tab = 'settings';
                if (!password_verify((string)($_POST['current'] ?? ''), $hash)) throw new RuntimeException('Current password is wrong.');
                $pw = (string)($_POST['password'] ?? '');
                if (strlen($pw) < 8) throw new RuntimeException('New password must be at least 8 characters.');
                if ($pw !== ($_POST['password2'] ?? '')) throw new RuntimeException('New passwords do not match.');
                if (!set_password($pw)) throw new RuntimeException('Could not save password.');
                flash('Password changed.');
                break;
        }
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'err');
    }
    redirect($tab);
}

/* ---------------- dashboard ---------------- */

$data = load_content();
$tab  = $_GET['tab'] ?? 'photos';
if (!in_array($tab, ['photos', 'products', 'settings'], true)) $tab = 'photos';
$editId = (string)($_GET['edit'] ?? '');
$editing = null;
foreach ($data['products'] as $p) if ($p['id'] === $editId) $editing = $p;
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
$csrf = csrf_token();
$v = '?v=' . time();

page_head('Admin | Infibird Concepts');
?>
<header class="top">
  <div class="wrap top__in">
    <a class="brand" href="index.php"><img src="../images/logo.svg" alt=""><span>Infibird <b>Admin</b></span></a>
    <div class="top__right">
      <a href="../" target="_blank" class="btn btn--light">View website ↗</a>
      <form method="post"><input type="hidden" name="csrf" value="<?= h($csrf) ?>"><button name="action" value="logout" class="btn btn--light">Log out</button></form>
    </div>
  </div>
  <nav class="wrap tabs">
    <a href="?tab=photos"   class="<?= $tab === 'photos' ? 'on' : '' ?>">Website Photos</a>
    <a href="?tab=products" class="<?= $tab === 'products' ? 'on' : '' ?>">Products (<?= count($data['products']) ?>)</a>
    <a href="?tab=settings" class="<?= $tab === 'settings' ? 'on' : '' ?>">Password</a>
  </nav>
</header>

<main class="wrap">
  <?php if ($flash): ?><div class="flash flash--<?= h($flash[1]) ?>"><?= h($flash[0]) ?></div><?php endif; ?>

  <?php if ($tab === 'photos'): ?>
    <h1>Website Photos</h1>
    <p class="muted">Tap <b>Change photo</b>, pick a picture from your phone or computer, and it goes live straight away. Landscape (wide) photos look best here.</p>
    <div class="grid">
      <?php foreach ($data['slots'] as $key => $s): ?>
        <form class="card" method="post" enctype="multipart/form-data">
          <div class="card__img"><img src="../<?= h($s['image']) . $v ?>" alt=""></div>
          <div class="card__body">
            <b><?= h($s['label']) ?></b>
            <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
            <input type="hidden" name="action" value="slot_upload">
            <input type="hidden" name="slot" value="<?= h($key) ?>">
            <label class="btn btn--primary btn--block file">
              Change photo
              <input type="file" name="photo" accept="image/jpeg,image/png,image/webp" onchange="this.form.classList.add('busy');this.form.submit()">
            </label>
          </div>
        </form>
      <?php endforeach; ?>
    </div>

  <?php elseif ($tab === 'products'): ?>
    <div class="split">
      <section>
        <h1><?= $editing ? 'Edit product' : 'Add a product' ?></h1>
        <form class="panel" method="post" enctype="multipart/form-data" id="pform">
          <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
          <input type="hidden" name="action" value="product_save">
          <input type="hidden" name="id" value="<?= h($editing['id'] ?? '') ?>">
          <label>Product name *<input name="name" required maxlength="120" value="<?= h($editing['name'] ?? '') ?>" placeholder="e.g. Mindray BC-20s Hematology Analyzer"></label>
          <div class="row">
            <label>Section
              <select name="category">
                <option value="instrument" <?= ($editing['category'] ?? '') !== 'consumable' ? 'selected' : '' ?>>Instruments</option>
                <option value="consumable" <?= ($editing['category'] ?? '') === 'consumable' ? 'selected' : '' ?>>Consumables &amp; Reagents</option>
              </select>
            </label>
            <label>Label<input name="tag" maxlength="30" value="<?= h($editing['tag'] ?? '') ?>" placeholder="Instrument / Reagent…"></label>
          </div>
          <label>Short description<textarea name="desc" rows="3" maxlength="400" placeholder="One or two lines about the product"><?= h($editing['desc'] ?? '') ?></textarea></label>
          <label>Photo <?= $editing ? '(leave empty to keep current)' : '*' ?>
            <?php if ($editing): ?><img class="thumb" src="../<?= h($editing['image']) . $v ?>" alt=""><?php endif; ?>
            <input type="file" name="photo" accept="image/jpeg,image/png,image/webp" <?= $editing ? '' : 'required' ?>>
          </label>
          <div class="row">
            <button class="btn btn--primary btn--block" onclick="document.getElementById('pform').classList.add('busy')"><?= $editing ? 'Save changes' : 'Add product' ?></button>
            <?php if ($editing): ?><a class="btn btn--light btn--block" href="?tab=products">Cancel</a><?php endif; ?>
          </div>
        </form>
      </section>

      <section>
        <h1>All products</h1>
        <p class="muted">Shown on the website in this order. Use ▲ ▼ to reorder.</p>
        <ul class="list">
          <?php foreach ($data['products'] as $i => $p): ?>
            <li class="<?= $p['id'] === $editId ? 'sel' : '' ?>">
              <img src="../<?= h($p['image']) . $v ?>" alt="">
              <div class="list__txt"><b><?= h($p['name']) ?></b><small><?= $p['category'] === 'consumable' ? 'Consumables' : 'Instruments' ?> · <?= h($p['tag']) ?></small></div>
              <div class="list__act">
                <form method="post"><input type="hidden" name="csrf" value="<?= h($csrf) ?>"><input type="hidden" name="action" value="product_move"><input type="hidden" name="id" value="<?= h($p['id']) ?>">
                  <button name="dir" value="up" class="ico" title="Move up" <?= $i === 0 ? 'disabled' : '' ?>>▲</button><button name="dir" value="down" class="ico" title="Move down" <?= $i === count($data['products']) - 1 ? 'disabled' : '' ?>>▼</button>
                </form>
                <a class="ico" href="?tab=products&amp;edit=<?= urlencode($p['id']) ?>" title="Edit">✎</a>
                <form method="post" onsubmit="return confirm('Delete “<?= h(addslashes($p['name'])) ?>”?')"><input type="hidden" name="csrf" value="<?= h($csrf) ?>"><input type="hidden" name="action" value="product_delete"><input type="hidden" name="id" value="<?= h($p['id']) ?>"><button class="ico ico--del" title="Delete">🗑</button></form>
              </div>
            </li>
          <?php endforeach; ?>
          <?php if (!$data['products']): ?><li class="muted">No products yet.</li><?php endif; ?>
        </ul>
      </section>
    </div>

  <?php else: ?>
    <h1>Change password</h1>
    <form class="panel narrow" method="post">
      <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
      <input type="hidden" name="action" value="password">
      <label>Current password<input type="password" name="current" required autocomplete="current-password"></label>
      <label>New password (min 8 characters)<input type="password" name="password" required minlength="8" autocomplete="new-password"></label>
      <label>Repeat new password<input type="password" name="password2" required minlength="8" autocomplete="new-password"></label>
      <button class="btn btn--primary btn--block">Change password</button>
    </form>
    <p class="muted small">Forgot the password? In Hostinger File Manager delete <code>admin/auth.php</code>, then open this page again to create a new one.</p>
  <?php endif; ?>
</main>
<div class="loading" aria-hidden="true"><span>Uploading…</span></div>
</body></html>
<?php

/* ---------------- views ---------------- */

function render_auth(string $mode, string $error): void {
    page_head($mode === 'setup' ? 'Create admin password' : 'Admin login');
    $csrf = csrf_token(); ?>
    <div class="auth">
      <form class="panel" method="post">
        <img src="../images/logo.svg" alt="" class="auth__logo">
        <h1><?= $mode === 'setup' ? 'Create your admin password' : 'Admin login' ?></h1>
        <p class="muted"><?= $mode === 'setup' ? 'First time here. Choose a strong password of at least 8 characters. You will use it to manage the website.' : 'Infibird Concepts website' ?></p>
        <?php if ($error): ?><div class="flash flash--err"><?= h($error) ?></div><?php endif; ?>
        <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
        <input type="hidden" name="action" value="<?= $mode ?>">
        <label>Password<input type="password" name="password" required <?= $mode === 'setup' ? 'minlength="8" autocomplete="new-password"' : 'autocomplete="current-password"' ?> autofocus></label>
        <?php if ($mode === 'setup'): ?><label>Repeat password<input type="password" name="password2" required minlength="8" autocomplete="new-password"></label><?php endif; ?>
        <button class="btn btn--primary btn--block"><?= $mode === 'setup' ? 'Create password' : 'Log in' ?></button>
        <a href="../" class="back">← Back to website</a>
      </form>
    </div>
    </body></html>
<?php }

function page_head(string $title): void { ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= h($title) ?></title>
<link rel="icon" type="image/svg+xml" href="../images/logo.svg">
<style>
:root{--navy:#0b2a55;--navy2:#123a72;--blue:#1d6fd1;--green:#2fb36b;--ink:#12213a;--muted:#5b6b82;--line:#e3e9f2;--soft:#f4f7fb;--red:#c53030}
*{box-sizing:border-box}body{margin:0;font:15px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--ink);background:var(--soft)}
h1{font-size:1.35rem;color:var(--navy);margin:28px 0 6px}.muted{color:var(--muted)}.small{font-size:.85rem}
.wrap{max-width:1150px;margin:0 auto;padding:0 16px}
.top{background:var(--navy);color:#fff;position:sticky;top:0;z-index:5}
.top__in{display:flex;justify-content:space-between;align-items:center;gap:10px;padding-top:10px;padding-bottom:10px}
.brand{display:flex;align-items:center;gap:8px;color:#fff;text-decoration:none;font-size:1.05rem}.brand img{width:32px;height:32px}.brand b{color:#7fe0a8}
.top__right{display:flex;gap:8px;align-items:center}.top__right form{margin:0}
.tabs{display:flex;gap:4px;overflow-x:auto}.tabs a{color:#b9c8de;text-decoration:none;padding:10px 14px;border-bottom:3px solid transparent;white-space:nowrap;font-weight:600}
.tabs a.on,.tabs a:hover{color:#fff;border-color:var(--green)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:0;border-radius:10px;padding:10px 16px;font:inherit;font-weight:600;cursor:pointer;text-decoration:none;white-space:nowrap}
.btn--primary{background:var(--green);color:#fff}.btn--primary:hover{background:#23965a}
.btn--light{background:rgba(255,255,255,.12);color:#fff}.btn--light:hover{background:rgba(255,255,255,.22)}
.panel .btn--light{background:var(--soft);color:var(--navy);border:1px solid var(--line)}
.btn--block{width:100%}
.flash{padding:12px 16px;border-radius:10px;margin:18px 0 0;font-weight:500}
.flash--ok{background:#e6f6ed;color:#1b7a47;border:1px solid #bfe8d0}.flash--err{background:#fdecec;color:var(--red);border:1px solid #f5c2c2}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:18px;margin:18px 0 40px}
.card{background:#fff;border:1px solid var(--line);border-radius:14px;overflow:hidden;margin:0}
.card__img{aspect-ratio:16/10;background:#eef2f7}.card__img img{width:100%;height:100%;object-fit:cover;display:block}
.card__body{padding:14px;display:flex;flex-direction:column;gap:10px}
.file{position:relative;overflow:hidden}.file input{position:absolute;inset:0;opacity:0;cursor:pointer;font-size:0}
.panel{background:#fff;border:1px solid var(--line);border-radius:14px;padding:20px;display:flex;flex-direction:column;gap:14px;margin:14px 0 30px}
.narrow{max-width:440px}
label{display:flex;flex-direction:column;gap:6px;font-weight:600;font-size:.9rem;color:var(--navy)}
input:not([type=file]):not([type=hidden]),select,textarea{font:inherit;font-size:16px;font-weight:400;padding:10px 12px;border:1.5px solid var(--line);border-radius:10px;background:var(--soft);color:var(--ink);width:100%}
input:focus,select:focus,textarea:focus{outline:none;border-color:var(--blue);background:#fff}
input[type=file]{font-weight:400;font-size:.9rem}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.thumb{width:140px;aspect-ratio:4/3;object-fit:cover;border-radius:8px;border:1px solid var(--line)}
.split{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.15fr);gap:28px;align-items:start}
.list{list-style:none;padding:0;margin:14px 0 40px;background:#fff;border:1px solid var(--line);border-radius:14px;overflow:hidden}
.list li{display:flex;align-items:center;gap:12px;padding:10px 12px;border-bottom:1px solid var(--line)}.list li:last-child{border-bottom:0}
.list li.sel{background:#eef5ff}
.list img{width:64px;height:48px;object-fit:cover;border-radius:6px;flex-shrink:0;background:#eef2f7}
.list__txt{flex:1;min-width:0;display:flex;flex-direction:column}.list__txt b{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.list__txt small{color:var(--muted)}
.list__act{display:flex;gap:4px;align-items:center}.list__act form{margin:0;display:flex;gap:4px}
.ico{width:34px;height:34px;display:inline-grid;place-items:center;border:1px solid var(--line);background:#fff;border-radius:8px;cursor:pointer;color:var(--navy);text-decoration:none;font-size:.85rem;padding:0}
.ico:hover:not([disabled]){border-color:var(--blue);color:var(--blue)}.ico[disabled]{opacity:.35;cursor:default}.ico--del:hover{border-color:var(--red)!important}
.auth{min-height:100vh;display:grid;place-items:center;padding:20px;background:linear-gradient(135deg,#071d3d,#123a72)}
.auth .panel{width:100%;max-width:400px;margin:0}.auth__logo{width:52px;height:52px}.auth h1{margin:0}.back{text-align:center;color:var(--muted);font-size:.9rem;text-decoration:none}
code{background:#e8edf5;padding:1px 6px;border-radius:5px}
.loading{position:fixed;inset:0;background:rgba(7,29,61,.55);display:none;place-items:center;z-index:50}
.loading span{background:#fff;padding:14px 22px;border-radius:12px;font-weight:600;color:var(--navy)}
body:has(.busy) .loading{display:grid}
@media(max-width:820px){.split{grid-template-columns:1fr;gap:0}}
@media(max-width:520px){.row{grid-template-columns:1fr}.top__right .btn{padding:8px 10px;font-size:.85rem}.brand span{display:none}.ico{width:30px;height:30px}.list img{width:48px;height:40px}.list li{gap:8px;padding:8px}}
</style>
</head>
<body>
<?php }
